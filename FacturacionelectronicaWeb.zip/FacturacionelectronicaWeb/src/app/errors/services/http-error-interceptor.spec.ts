import { HttpErrorInterceptor } from './http-error-interceptor';

describe('HttpErrorInterceptor', () => {
  it('should create an instance', () => {
    expect(new HttpErrorInterceptor()).toBeTruthy();
  });
});
