export class Cliente {
    public guid: string;
    public nombre: string;
    public numero: string;
    public tipoDeDocumentoGuid: string;
    public tipoDeDocumentoDescripcion: string;
}
