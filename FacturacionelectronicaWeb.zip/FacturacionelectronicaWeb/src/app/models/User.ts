 export class User {

     constructor(
        public guid: string, 
        public nombreUsuario: string,
        public nombre: string,
        public contrasena: string) {}
     
}