export class EstacionUI {
    constructor(
        public guid: string,
        public nit: string,
        public nombre: string,
        public direccion: string,
        public razon: string,
        public linea1: string,
        public linea2: string,
        public linea3: string,
        public linea4: string,
        public telefono: string,
        public seleccionado: boolean) {}
}
