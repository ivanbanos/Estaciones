export class ClientesUI {
    constructor(public guid: string,
                public nombre: string,
                public numero: string,
                public tipoDeDocumentoDescripcion: string) {}
}
