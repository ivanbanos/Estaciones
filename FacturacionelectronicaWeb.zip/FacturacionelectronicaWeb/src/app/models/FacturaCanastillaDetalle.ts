export interface FacturaCanastillaDetalle {
    descripcion: string;
    cantidad : number;
    precio : number;
    subtotal : number;
    iva : number;
    total : number;
}