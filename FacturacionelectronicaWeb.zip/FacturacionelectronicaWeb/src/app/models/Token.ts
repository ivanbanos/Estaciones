export class Token {
    constructor(public type: string, public token: string){}
}