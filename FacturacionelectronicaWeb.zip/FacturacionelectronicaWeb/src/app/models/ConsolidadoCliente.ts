export class ConsolidadoCliente {
    cliente: string;
    cantidad: number;
    total: number;
}
