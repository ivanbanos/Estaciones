

export class Resolucion {
    public guid: string;
    public consecutivoInicial: number;
    public consecutivoFinal: number;
    public fechaInicial: Date;
    public fechaFinal: Date;
    public idEstado: string;
    public estado: string;
    public consecutivoActual: number;
    public fecha: Date;
    public idEstacion: string;
    public autorizacion: string;
    public habilitada: boolean;
    public descripcion: string;
    public tipo:number;
}
