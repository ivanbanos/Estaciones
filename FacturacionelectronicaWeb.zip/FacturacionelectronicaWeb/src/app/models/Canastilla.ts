export interface Canastilla {
    guid: string;
    descripcion: string;
    unidad: string;
    precio: number;
    deleted: boolean;
    iva : number;
}
