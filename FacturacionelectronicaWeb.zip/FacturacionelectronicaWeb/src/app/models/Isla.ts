export class Isla {

    constructor(
       public guid: string, 
       public nombre: string,
       public estado: number) {}
    
}