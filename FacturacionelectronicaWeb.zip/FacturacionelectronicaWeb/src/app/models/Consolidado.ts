export interface Consolidado {
    combustible: string;
    cantidad: number;
    total: number;
}
