import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-info-busqueda',
  templateUrl: './info-busqueda.component.html',
  styleUrls: ['./info-busqueda.component.sass']
})
export class InfoBusquedaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
