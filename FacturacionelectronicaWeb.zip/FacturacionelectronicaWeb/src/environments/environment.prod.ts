export const environment = {
  production: true,
  serverUrl: 'https://inversaldana.api.sigessoluciones.com/api',
  name: 'production'
};
